/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.up.edu;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author DCS
 */
public class Crawler {
    Passers p = null;
    public Crawler(){
        p = new Passers();
    }
    
    public static void main(String[] args) {
            
            Crawler c = new Crawler();
            Logger  logger = Logger.getLogger("com.up.edu.Crawler");
            logger.setLevel(Level.INFO);
            System.out.println("Crawling UPCAT Passers Site..");
            c.crawlAllPassers();
            String unit = "CEBU";
            String[] programs = {"BS COMPUTER SCIENCE","BS PSYCHOLOGY", "BS BIOLOGY", "BS MATHEMATICS", "BA POLITICAL SCIENCE", "BA PYSCHOLOGY", "BA MASS COMMUNICATION", "B FINE ARTS (STUDIO ARTS)", "B FINE ARTS (PRODUCT DESIGN)"};
            System.out.println("Listing UPCAT passers in UP Cebu programs.");
            for (int k = 0; k < programs.length; k++) {
                System.out.println(programs[k]+" program:");
                List l = c.p.getPassers(unit, programs[k]);
                Iterator i  = l.iterator();
                int ctr = 0;
                if(i.hasNext()){
                    while(i.hasNext()){
                        ctr++;
                        System.out.println(ctr+". "+i.next());
                    }
                }else{
                    System.out.println("None.");
                }
            }
            
            
            
    }
    
    public void crawlAllPassers(){
        String page = "";
        String pre = "http://upcat.up.edu.ph/results/page-";
        String post = ".html";
        String url = "";
        try{
            for (int i = 1; i < 10; i++) {
                page = "00"+i;
                url = pre+page+post;
                System.out.print("Page "+page+"...");
                crawlPassersPerPage(url);
                System.out.println("done");
                if(i==9){
                    break;
                }   
            }
            for (int i = 10; i <100; i++) {
                page = "0"+i;
                url = pre+page+post;
                System.out.print("Page "+page+"...");
                crawlPassersPerPage(url);
                System.out.println("done");
                if(i==99)
                    break;
            }
            for (int i = 100; i <= 150; i++) {
                url = pre+i+post;
                System.out.print("Page "+i+"...");
                crawlPassersPerPage(url);
                System.out.println("done");
                if(i==150)
                    break;
            }
        }catch(FileNotFoundException ex){
            System.out.println("Not found.");
        }catch (MalformedURLException ex) {
            Logger.getLogger(Crawler.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Crawler.class.getName()).log(Level.SEVERE, null, ex);
        } 
        finally{
            System.out.println("Crawling done.");
        }
        
    }
    
    public void crawlPassersPerPage(String url) throws FileNotFoundException, MalformedURLException,IOException{
//        try {
            URL u = new URL(url);
            InputStream is= u.openStream();
            InputStreamReader isr = new InputStreamReader(is);
            BufferedReader br = new BufferedReader(isr);
            String s = br.readLine();
            String endS = "Previous";
            int ctr = 0;
            boolean end = false;
            String validInfo = "printable";
            String name="", course="",campus=""; 
            Applicant a = null;
            int ctrPerApplicant=1;
            
            while(s!=null){
                ctr++;
                if(s.contains(endS)){
                    end = true;
                }
                if(ctr>=45 && !end && s.contains(validInfo)){
                    if(ctrPerApplicant==1){
                        a = new Applicant();
                        //System.out.println(s);
                        s = getContentsOnly(s);
                        if(s.contains("see notes")){
                            s = s.substring(0, s.length()-34);
                            //System.out.println(s);
                        }
                        a.setName(s);
                        ctrPerApplicant++;
                    }else if(ctrPerApplicant==2){
                        //System.out.println(s);
                        a.setCampus(getContentsOnly(s));
                        ctrPerApplicant++;
                    }else if(ctrPerApplicant==3){
                        //System.out.println(s);
                        a.setCourse(getContentsOnly(s));
                        p.addIntoPassersList(a);
                        ctrPerApplicant=1;
                    }
                        
                }
                    
                s = br.readLine();
            }
//        } catch(FileNotFoundException ex){
//            System.out.println("Not found.");
//            Logger.getLogger(Crawler.class.getName()).log(Level.SEVERE, null, ex);
//        }catch (MalformedURLException ex) {
//            Logger.getLogger(Crawler.class.getName()).log(Level.SEVERE, null, ex);
//        } catch (IOException ex) {
//            Logger.getLogger(Crawler.class.getName()).log(Level.SEVERE, null, ex);
//        } 
    }
    public static String getContentsOnly(String s){
        String pre = "<td class=\"printable\">";
        String post = "</td>";
        String[] s1 = s.split(pre);
        //System.out.println(s1[1]);
        String[] s2 = s1[1].split(post);
        //System.out.println(s2[0]);
        return s2[0];
    }
}
